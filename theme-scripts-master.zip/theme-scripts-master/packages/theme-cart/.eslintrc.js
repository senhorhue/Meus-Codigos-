module.exports = {
  globals: {
    Promise: true
  }
};
